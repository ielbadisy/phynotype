## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(phynotype)

## -----------------------------------------------------------------------------
fit <- cluster(iris[, 1:4], method = "kmeans", k = 3, seed = 1)
fit
summary(fit)

## -----------------------------------------------------------------------------
val <- validate(fit)
val$metrics_table

## -----------------------------------------------------------------------------
exp <- explore(fit)
head(exp$feature_summary)
head(exp$separation_table)

## -----------------------------------------------------------------------------
plot_clusters(fit)
plot_silhouette(fit)
plot_validation(val)
plot_cluster_sizes(fit)
plot_feature_profiles(exp)

## -----------------------------------------------------------------------------
pred <- predict(fit, iris[1:10, 1:4])
pred

