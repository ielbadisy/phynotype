## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(phynotype)

## -----------------------------------------------------------------------------
mfit <- metacluster(
  iris[, 1:4],
  methods = c("kmeans", "pam", "hclust"),
  k = 2:5,
  consensus = "coassoc",
  seed = 1
)

mfit
summary(mfit)
head(mfit$candidate_table)

## -----------------------------------------------------------------------------
dim(mfit$coassoc_matrix)
head(mfit$selection_summary)

## -----------------------------------------------------------------------------
mval <- validate(mfit)
mval$metrics_table

## -----------------------------------------------------------------------------
mexp <- explore(mfit)
head(mexp$feature_summary)

## -----------------------------------------------------------------------------
plot_consensus(mfit)
plot_coassoc(mfit)
plot_validation(mval)

