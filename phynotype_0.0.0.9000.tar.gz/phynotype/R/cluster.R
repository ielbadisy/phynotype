#' Fit a clustering solution
#'
#' Fit a single clustering solution using a supported method.
#'
#' @param x Numeric matrix or numeric data frame.
#' @param method Clustering method. Supported values are `"kmeans"`,
#'   `"pam"`, and `"hclust"`.
#' @param ... Additional method-specific arguments.
#' @param k Number of clusters for methods that require it.
#' @param scale Logical; if `TRUE`, scale columns before fitting.
#' @param center Logical; if `TRUE`, center columns before fitting.
#' @param seed Optional integer random seed.
#'
#' @return A `cluster_fit` object.
#' @examples
#' fit <- cluster(iris[, 1:4], method = "kmeans", k = 3, seed = 1)
#' fit
#' @export
cluster <- function(x,
                    method = "kmeans",
                    ...,
                    k = NULL,
                    scale = FALSE,
                    center = TRUE,
                    seed = NULL) {
  args <- list(...)
  method <- normalize_method_name(method)
  registry <- get_cluster_registry()
  entry <- registry[[method]]
  if (is.null(entry)) {
    stop("Unsupported clustering method: ", method, call. = FALSE)
  }

  checked <- prepare_cluster_input(
    x = x,
    method = method,
    scale = scale,
    center = center,
    k = k
  )

  if (!is.null(seed)) {
    validate_seed(seed)
  }

  params <- utils::modifyList(list(k = k), args)
  params$scale <- scale
  params$center <- center
  params$seed <- seed

  if (!is.null(entry$validate)) {
    entry$validate(checked$data, params)
  }

  fit <- with_seed(seed, entry$fit(data = checked$data, params = params))

  new_cluster_fit(
    method = method,
    call = match.call(),
    params = params,
    clusters = fit$clusters,
    n_clusters = fit$n_clusters,
    membership = fit$membership,
    centers = fit$centers,
    prototypes = fit$prototypes,
    distance_info = fit$distance_info,
    fitted_object = fit$fitted_object,
    data_info = checked$data_info,
    extras = fit$extras
  )
}
