#' Fit a consensus meta-clustering solution
#'
#' @param x Numeric matrix or numeric data frame.
#' @param methods Character vector of clustering methods.
#' @param k Candidate numbers of clusters.
#' @param consensus Consensus method. Only `"coassoc"` is supported in v1.
#' @param final_k Optional final number of consensus clusters.
#' @param scale Logical; if `TRUE`, scale columns before fitting.
#' @param center Logical; if `TRUE`, center columns before fitting.
#' @param seed Optional integer random seed.
#' @param ... Additional method-specific arguments passed through to candidate fits.
#'
#' @return A `metacluster_fit` object.
#' @export
metacluster <- function(x,
                        methods = c("kmeans", "pam", "hclust"),
                        k = 2:5,
                        consensus = "coassoc",
                        final_k = NULL,
                        scale = FALSE,
                        center = TRUE,
                        seed = NULL,
                        ...) {
  methods <- validate_methods_vector(methods)
  if (!identical(consensus, "coassoc")) {
    stop("Only `consensus = \"coassoc\"` is supported in v1.", call. = FALSE)
  }
  k_values <- check_k_grid(k)
  checked <- prepare_cluster_input(x, method = "kmeans", scale = scale, center = center, k = 2L)
  if (inherits(checked$data_info$original_data, "dist")) {
    stop("`metacluster()` currently requires a numeric matrix or data frame.", call. = FALSE)
  }

  candidate_fits <- list()
  candidate_labels <- list()
  candidate_rows <- vector("list", length(methods) * length(k_values))
  row_id <- 1L

  for (method in methods) {
    for (k_i in k_values) {
      fit <- cluster(
        checked$data_info$original_data,
        method = method,
        k = k_i,
        scale = scale,
        center = center,
        seed = seed,
        ...
      )
      candidate_fits[[row_id]] <- fit
      candidate_labels[[row_id]] <- clusters(fit)
      candidate_rows[[row_id]] <- data.frame(
        candidate_id = row_id,
        method = method,
        k = k_i,
        observed_k = length(unique(clusters(fit))),
        stringsAsFactors = FALSE
      )
      row_id <- row_id + 1L
    }
  }

  candidate_rows <- candidate_rows[seq_len(row_id - 1L)]
  candidate_table <- do.call(rbind, candidate_rows)
  coassoc <- compute_coassoc_matrix(candidate_labels)
  consensus_dist <- stats::as.dist(1 - coassoc)
  selector <- if (is.null(final_k)) select_consensus_k(consensus_dist, k_values) else {
    list(final_k = as.integer(final_k), score_table = data.frame(k = k_values, silhouette = NA_real_))
  }
  hc <- stats::hclust(consensus_dist, method = "average")
  final_clusters <- stats::cutree(hc, k = selector$final_k)

  new_metacluster_fit(
    call = match.call(),
    params = list(
      methods = methods,
      k = k_values,
      consensus = consensus,
      scale = scale,
      center = center,
      seed = seed,
      final_k = selector$final_k
    ),
    candidate_fits = candidate_fits,
    candidate_labels = candidate_labels,
    candidate_table = candidate_table,
    coassoc_matrix = coassoc,
    consensus_dissimilarity = consensus_dist,
    consensus_fit = hc,
    final_clusters = final_clusters,
    final_k = selector$final_k,
    selection_summary = selector$score_table,
    stability_summary = compute_metacluster_stability(candidate_labels),
    data_info = checked$data_info,
    extras = list(consensus = consensus)
  )
}
