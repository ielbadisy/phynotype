# Design Note

## Supported in v1

- `cluster()` for `kmeans`, `pam`, `hclust`, `agnes`, `dbscan`, and `gmm`
- `metacluster()` with co-association consensus clustering
- `validate()` for fitted objects and direct `k` grids
- `explore()` with cluster summaries, separation scores, and PCA embeddings
- `predict()` for `kmeans`, `pam`, `gmm`, and `dbscan` when package support is available
- plotting helpers for cluster embeddings, validation, feature profiles, cluster sizes, dendrograms, and co-association heatmaps

## Intentionally unsupported or limited

- no `set_engine()` grammar
- no fake prediction for hierarchical clustering methods
- no mixed-type clustering API in v1
- no fuzzy or spectral clustering in v1
- no scalability claims beyond moderate sample sizes for consensus clustering

## How `metacluster()` works

1. Fit candidate partitions across methods and `k`.
2. Convert each partition to a pairwise co-clustering indicator matrix.
3. Average those matrices to form the co-association matrix.
4. Convert `1 - coassociation` to a consensus dissimilarity.
5. Cluster the consensus dissimilarity with hierarchical clustering.
6. Cut the consensus tree at `final_k`, or choose `final_k` by average silhouette on the consensus dissimilarity.

## Prediction behavior

- `kmeans`: nearest centroid assignment
- `pam`: nearest medoid assignment
- `gmm`: posterior membership and hard classification
- `dbscan`: delegated to package support when available
- `hclust` and `agnes`: unsupported because prediction is not natively defined
